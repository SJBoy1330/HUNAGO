var gModul = 'blog/';
var url = baseUrl + gModul;

$(document).ready(function(){

    var myEditor;
    
    $("#tanggal").flatpickr({
        dateFormat: "d-m-Y"
    });


    ClassicEditor.create( document.querySelector( '#detail' ), {
        toolbar: {
            items: [
                'bold',
                'italic',
                'alignment',
                '|',
                'mediaBrowser',
                'htmlEmbed',
                'undo',
                'redo'
            ]
        },
        language: 'en',
        image: {
            toolbar: [
                'imageTextAlternative',
                'imageStyle:full',
                'imageStyle:side'
            ]
        },
        table: {
            contentToolbar: [
                'tableColumn',
                'tableRow',
                'mergeTableCells'
            ]
        },
        licenseKey: ''
        
        
    } )
    .then( editor => {
        //window.editor = editor;
        myEditor = editor;
    } )
    .catch( error => {
        console.error( 'Oops, something went wrong!' );
        console.error( 'Please, report the following error on https://github.com/ckeditor/ckeditor5/issues with the build id and the error stack trace:' );
        console.warn( 'Build id: vd7qnogyyu6n-nohdljl880ze' );
        console.error( error );
    } );



	$("#submit_blog").on('click', function(e){

		e.preventDefault();

        $(this).prop('disabled', true);
        setTimeout('$("#submit_blog").removeAttr("disabled")', 2000);
		
		var form = $('form')[0];
		var formData = new FormData(form);

        var detail = myEditor.getData($("#detail").val());
        formData.append('detail', detail);


		$.ajax({
			type: 'POST', 
			url: url + 'save_add',
			data:formData,
			cache: false,
			contentType : false,
			processData: false, 
			success: function (respdata){

				if (respdata.status == 'NOK'){
					Swal.fire({
					  title: 'Pesan Gagal!',
					  html: respdata.message,
					  icon: 'error',
					  confirmButtonText: 'Tutup'
					})
				}else{
					Swal.fire({
					  title: 'Pesan Sukses!',
					  html: respdata.message,
					  icon: 'success',
					  confirmButtonText: 'Lanjutkan',
					}).then(function(){
						document.location.href= url ;
					})
				}

			}, 
			error: function (respdata){
				Swal.fire({
				  title: 'Pesan Gagal!',
				  html: 'Gagal menambahkan Blog',
				  icon: 'error',
				  confirmButtonText: 'Tutup'
				})
			}
		});
	})
})