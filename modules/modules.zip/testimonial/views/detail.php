<div class="row mb-7">
	<!--begin::Label-->
	<label for="nama" class="col-sm-4 col-12 text-muted">
		Nama
	</label>
	<!--end::Label-->
	<div class="col-sm-8 col-12">
		<div class="fw-bolder fs-6 text-gray-800"><?=$result->nama?></div>
	</div>
</div>
<div class="row mb-7">
	<!--begin::Label-->
	<label for="profesi" class="col-sm-4 col-12 text-muted">
		Profesi
	</label>
	<!--end::Label-->
	<div class="col-sm-8 col-12">
		<div class="fw-bolder fs-6 text-gray-800"><?=$result->profesi?></div>
	</div>
</div>
<div class="row mb-7">
	<!--begin::Label-->
	<label for="foto" class="col-sm-4 col-12 text-muted">
		Foto
	</label>
	<!--end::Label-->
	<div class="col-sm-8 col-12">
		<div class="fw-bolder fs-6 text-gray-800">
            <?php 
                if ($result->foto != "" && file_exists($this->data_path.'testimonial/'.$result->foto)){
                    $encimg = setencrypt($result->foto);
                    $url = site_url('media/image_access_testimonial/'.$encimg);
                }else{
                    $url = site_url('media/no_image');
                }
            ?>
            <img src="<?=$url?>" width="200">
        </div>
	</div>
</div>
<div class="row mb-7">
	<!--begin::Label-->
	<label for="testimoni" class="col-sm-4 col-12 text-muted">
		Testimoni
	</label>
	<!--end::Label-->
	<div class="col-sm-8 col-12">
		<div class="fs-6 text-gray-800"><?=$result->detail?></div>
	</div>
</div>
<div class="row mb-7">
	<!--begin::Label-->
	<label for="email" class="col-sm-4 col-12 text-muted">
		Tanggal
	</label>
	<!--end::Label-->
	<div class="col-sm-8 col-12">
		<div class="fw-bolder fs-6 text-gray-800"><?=reverse_fulldate($result->tanggal)?></div>
	</div>
</div>
