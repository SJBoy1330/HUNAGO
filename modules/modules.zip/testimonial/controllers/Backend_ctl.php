<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Backend_ctl extends MY_Admin {

    protected $mydata;

    var $data_path = "";

    function __construct(){
        parent::__construct();

        if (!$this->oitocauth->is_loggedin()){
            redirect(site_url('auth'));
        }

        $this->load->model('testimonial_m');
        $this->data_path = $this->config->item('data_path');
    }

    public function index(){

        $this->data['pagetitle'] = "Testimonial"; 

        $mydata['parent'] = 'Testimonial';
        $mydata['arrchild'][] = array('link' => site_url('dashboard'), 'name' => 'Dashboard');
        $mydata['arrchild'][] = array('link' => '#', 'name' => 'Testimonial');

        $this->data['css_add'][] = '<link href="'.base_url('assets/dist/assets/plugins/custom/datatables/datatables.bundle.css').'" rel="stylesheet" type="text/css" />';

        $this->data['js_add'][] = '<script src="'.base_url('assets/dist/assets/plugins/custom/datatables/datatables.bundle.js').'"></script>';

        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/js/page/testimonial/testimonial.js').'"></script>';

        $result = $this->testimonial_m->get_testimonial('',0,0);
        $mydata['result'] = $result;

        $mydata['data_path'] = $this->data_path;

        $this->data['content']=$this->load->view('index',$mydata,true);

        $this->display();
    }

    public function add(){

        $this->data['pagetitle'] = "Tambah Testimonial"; 

        $mydata['parent'] = 'Tambah Testimonial';
        $mydata['arrchild'][] = array('link' => site_url('dashboard'), 'name' => 'Dashboard');
        $mydata['arrchild'][] = array('link' => site_url('Testimonial'), 'name' => 'Testimonial');
        $mydata['arrchild'][] = array('link' => '#', 'name' => 'Tambah Testimonial');

        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/js/page/testimonial/add_testimonial.js').'"></script>';

        $result = $this->testimonial_m->get_testimonial('',0,0);
        $mydata['result'] = $result;

        $mydata['data_path'] = $this->data_path;

        $this->data['content']=$this->load->view('add',$mydata,true);

        $this->display();
    }

    public function save_add(){

        header("Content-type: text/json");

        $arrVar = array('nama', 'profesi', 'detail', 'tampil');
        foreach($arrVar as $var){
            $$var = $this->input->post($var);
        }

        $this->form_validation->set_rules('nama', 'Nama', 'required', array('required' => 'Nama harus diisi'));
        $this->form_validation->set_rules('profesi', 'Profesi', 'required', array('required' => 'Profesi harus diisi'));
        $this->form_validation->set_rules('detail', 'Testimoni', 'required', array('required' => 'Testimoni harus diisi'));

        if ($this->form_validation->run() === FALSE){
            $response['status'] = 'NOK';
            $response['message'] = validation_errors();
            echo json_encode($response);
            exit;
        }

        if (!empty($_FILES['foto']['tmp_name'])){
            $config['upload_path'] = $this->data_path.'testimonial';
            $config['allowed_types'] = '*';
            $config['file_name'] = uniqid();
            $config['file_ext_tolower'] = true;
        
            $this->load->library('upload', $config);

            $data=[];

            if (! $this->upload->do_upload('foto')){
                $error = array('error' => $this->upload->display_errors());
                $response['status'] = 'NOK';
                $response['message'] = 'Gagal mengupload file: '.$error['error'];//.$error['error'].' '.$_FILES['gambar']['type'];
                echo json_encode($response);
                exit;
            }else{

                $data = array('upload_data' => $this->upload->data());

            }

            $foto = $data['upload_data']['file_name'];
            $arrInsert['foto'] = $foto;
        }else{
            $response['status'] = "NOK";
            $response['message'] = 'File Gambar masih kosong';
            echo json_encode($response);
            exit;
        }

        $arrInsert['nama'] = $nama;
        $arrInsert['profesi'] = $profesi;
        $arrInsert['profesi'] = $detail;
        $arrInsert['tampil'] = $tampil;
        $arrInsert['tanggal'] = date('Y-m-d H:i:s');

        if ($this->testimonial_m->insert_testimonial($arrInsert)){
            $response['status'] = 'OK';
            $response['message'] = 'Berhasil menambahkan Testimonial';
        }else{
            $response['status'] = 'NOK';
            $response['message'] = 'Gagal menambahkan Testimonial';
        }
        echo json_encode($response);
        exit;

    }

    public function edit(){
        
        $this->data['pagetitle'] = "Update Testimonial"; 

        $id_testimonial = $this->uri->segment(3);

        $mydata['parent'] = 'Update Testimonial';
        $mydata['arrchild'][] = array('link' => site_url('dashboard'), 'name' => 'Dashboard');
        $mydata['arrchild'][] = array('link' => site_url('testimonial'), 'name' => 'Testimonial');
        $mydata['arrchild'][] = array('link' => '#', 'name' => 'Update Testimonial');

        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/js/page/testimonial/edit_testimonial.js').'"></script>';

        $result = $this->testimonial_m->get_single_Testimonial(array('id_testimonial' => $id_testimonial));
        $mydata['result'] = $result;

        $mydata['data_path'] = $this->data_path;

        $this->data['content']=$this->load->view('edit',$mydata,true);

        $this->display();
    }

    public function save_edit(){
        
        header("Content-type: text/json");

        $arrVar = array('id_testimonial', 'nama', 'profesi', 'detail', 'tampil');
        foreach($arrVar as $var){
            $$var = $this->input->post($var);
        }

        $this->form_validation->set_rules('nama', 'Nama', 'required', array('required' => 'Nama harus diisi'));
        $this->form_validation->set_rules('profesi', 'Profesi', 'required', array('required' => 'Profesi harus diisi'));
        $this->form_validation->set_rules('detail', 'Testimoni', 'required', array('required' => 'Testimoni harus diisi'));

        if ($this->form_validation->run() === FALSE){
            $response['status'] = 'NOK';
            $response['message'] = validation_errors();
            echo json_encode($response);
            exit;
        }

        $testimonial = $this->testimonial_m->get_single_testimonial(array('nama' => $nama));
        if ($testimonial){
            if ($testimonial->id_testimonial != $id_testimonial){
                $response['status'] = "NOK";
                $response['message'] = "Testimonial Sudah ada ";
                echo json_encode($response);
                exit;
            }
        }

        if (!empty($_FILES['foto']['tmp_name'])){
            $config['upload_path'] = $this->data_path.'testimonial';
            $config['allowed_types'] = '*';
            $config['file_name'] = uniqid();
            $config['file_ext_tolower'] = true;
        
            $this->load->library('upload', $config);

            $data=[];

            if (! $this->upload->do_upload('foto')){
                $error = array('error' => $this->upload->display_errors());
                $response['status'] = 'NOK';
                $response['message'] = 'Gagal mengupload file: '.$error['error'];//.$error['error'].' '.$_FILES['gambar']['type'];
                echo json_encode($response);
                exit;
            }else{

                if ($testimonial->foto != "" && file_exists($this->data_path.'testimonial/'.$testimonial->foto)){
                    unlink($this->data_path.'testimonial/'.$testimonial->foto);
                }

                $data = array('upload_data' => $this->upload->data());

            }

            $foto = $data['upload_data']['file_name'];
            $arrUpdate['foto'] = $foto;
        }

        $arrUpdate['nama'] = $nama;
        $arrUpdate['profesi'] = $profesi;
        $arrUpdate['detail'] = $detail;
        $arrUpdate['tampil'] = $tampil;

        if ($this->testimonial_m->update_testimonial($arrUpdate, $id_testimonial)){
            $response['status'] = 'OK';
            $response['message'] = 'Berhasil mengubah Testimonial';
        }else{
            $response['status'] = 'NOK';
            $response['message'] = 'Gagal mengubah Testimonial';
        }

        echo json_encode($response);

        exit;
    }

    public function detail(){

        $id_testimonial = $this->input->post('id_testimonial');

        $result = $this->testimonial_m->get_single_testimonial(array('id_testimonial' => $id_testimonial));

        $data['result'] = $result;

        $this->load->view('detail', $data);
    }

    public function delete(){
        header("Content-type: text/json");

        $id_Testimonial = $this->input->post('id_Testimonial');

        $res = $this->testimonial_m->get_single_Testimonial(array('id_Testimonial' => $id_Testimonial));

        if (!$res){
            $response['status'] = 'NOK';
            $response['message'] = 'Data tidak ditemukan';
            echo json_encode($response);
            exit;
        }

        $resdelete = $this->testimonial_m->delete_Testimonial($id_Testimonial);
        if ($resdelete){

            if ($res->foto != '' && file_exists($this->data_path.'testimonial/'.$res->foto)){
                unlink($this->data_path.'testimonial/'.$res->foto);
            }

            $response['status'] = 'OK';
            $response['message'] = 'Berhasil menghapus Testimonial';
        }else{
            $response['status'] = 'NOK';
            $response['message'] = 'Gagal menghapus Testimonial';
        }
        
        echo json_encode($response);

        exit;
    }

    public function delete_all(){
        header("Content-type: text/json");

        if (count($_POST['items'])>0){
            foreach($_POST['items'] as $val){
                $res = $this->testimonial_m->get_single_Testimonial(array('id_testimonial' => $val));

                $foto = $res->foto;

                if ($foto != '' && file_exists($this->data_path.'testimonial/'.$foto)){
                    unlink($this->data_path.'testimonial/'.$foto);
                }
                
                $this->testimonial_m->delete_Testimonial($val);
            }
        }

        $response['status'] = 'OK';
        $response['message'] = 'Berhasil menghapus Testimonial';

        echo json_encode($response);
        exit;
    }

}