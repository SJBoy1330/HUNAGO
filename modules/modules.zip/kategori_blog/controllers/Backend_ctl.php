<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Backend_ctl extends MY_Admin {

    protected $mydata;

    var $data_path = "";

    function __construct(){
        parent::__construct();

        if (!$this->oitocauth->is_loggedin()){
            redirect(site_url('auth'));
        }

        $this->load->model('blog_kategori_m');
        $this->data_path = $this->config->item('data_path');
    }

    public function index(){

        $this->data['pagetitle'] = "Kategori Blog"; 

        $mydata['parent'] = 'Kategori Blog';
        $mydata['arrchild'][] = array('link' => site_url('dashboard'), 'name' => 'Dashboard');
        $mydata['arrchild'][] = array('link' => '#', 'name' => 'Kategori Blog');

        $this->data['css_add'][] = '<link href="'.base_url('assets/dist/assets/plugins/custom/datatables/datatables.bundle.css').'" rel="stylesheet" type="text/css" />';

        $this->data['js_add'][] = '<script src="'.base_url('assets/dist/assets/plugins/custom/datatables/datatables.bundle.js').'"></script>';

        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/js/page/kategori_blog/kategori_blog.js').'"></script>';

        $result = $this->blog_kategori_m->get_blog_kategori('',0,0);
        $mydata['result'] = $result;

        $mydata['data_path'] = $this->data_path;

        $this->data['content']=$this->load->view('index',$mydata,true);

        $this->display();
    }

    public function add(){

        $this->data['pagetitle'] = "Tambah Kategori Blog"; 

        $mydata['parent'] = 'Tambah Kategori Blog';
        $mydata['arrchild'][] = array('link' => site_url('dashboard'), 'name' => 'Dashboard');
        $mydata['arrchild'][] = array('link' => site_url('kategori_blog'), 'name' => 'Kategori Blog');
        $mydata['arrchild'][] = array('link' => '#', 'name' => 'Tambah Kategori Blog');

        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/js/page/kategori_blog/add_kategori_blog.js').'"></script>';

        $result = $this->blog_kategori_m->get_blog_kategori('',0,0);
        $mydata['result'] = $result;

        $mydata['data_path'] = $this->data_path;

        $this->data['content']=$this->load->view('add',$mydata,true);

        $this->display();
    }

    public function save_add(){

        header("Content-type: text/json");

        $nama = $this->input->post('nama');

        if ($nama == ''){
            $response['status'] = 'NOK';
            $response['message'] = 'Kategori Blog tidak boleh kosong';
            echo json_encode($response);
            exit;
        }

        $kategori = $this->blog_kategori_m->get_single_blog_kategori(array('nama' => $nama));

        if ($kategori){
            $response['status'] = 'NOK';
            $response['message'] = 'Kategori Blog sudah ada, silakan isi dengan yang lain';
            echo json_encode($response);
            exit;
        }

        $arrInsert = array('nama' => $nama);

        if ($this->blog_kategori_m->insert_blog_kategori($arrInsert)){
            $response['status'] = 'OK';
            $response['message'] = 'Berhasil menambahkan Kategori Blog';
        }else{
            $response['status'] = 'NOK';
            $response['message'] = 'Gagal menambahkan Kategori Blog';
        }
        echo json_encode($response);
        exit;

    }

    public function edit(){
        
        $this->data['pagetitle'] = "Update Kategori Blog"; 

        $id_kategori = $this->uri->segment(3);

        $mydata['parent'] = 'Update Kategori Blog';
        $mydata['arrchild'][] = array('link' => site_url('dashboard'), 'name' => 'Dashboard');
        $mydata['arrchild'][] = array('link' => site_url('kategori_blog'), 'name' => 'Kategori Blog');
        $mydata['arrchild'][] = array('link' => '#', 'name' => 'Update Kategori Blog');

        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/js/page/kategori_blog/edit_kategori_blog.js').'"></script>';

        $result = $this->blog_kategori_m->get_single_blog_kategori(array('id_blog_kategori' => $id_kategori));
        $mydata['result'] = $result;

        $mydata['data_path'] = $this->data_path;

        $this->data['content']=$this->load->view('edit',$mydata,true);

        $this->display();
    }

    public function save_edit(){
        
        header("Content-type: text/json");

        $id_blog_kategori = $this->input->post('id_blog_kategori');
        $nama = $this->input->post('nama');

        if ($nama == ""){
            $response['status'] = "NOK";
            $response['message'] = "Nama tidak boleh kosong";
            echo json_encode($response);
            exit;
        }

        $kategori = $this->blog_kategori_m->get_single_blog_kategori(array('nama' => $nama));
        if ($kategori){
            if ($kategori->id_blog_kategori != $id_blog_kategori){
                $response['status'] = "NOK";
                $response['message'] = "Kategori Sudah ada ";
                echo json_encode($response);
                exit;
            }
        }

        $arrUpdate = array('nama' => $nama);

        if ($this->blog_kategori_m->update_blog_kategori($arrUpdate, $id_blog_kategori)){
            $response['status'] = 'OK';
            $response['message'] = 'Berhasil mengubah Kategori Blog';
        }else{
            $response['status'] = 'NOK';
            $response['message'] = 'Gagal mengubah Kategori Blog';
        }

        echo json_encode($response);

        exit;
    }

    public function delete(){
        header("Content-type: text/json");

        $id_blog_kategori = $this->input->post('id_blog_kategori');

        $res = $this->blog_kategori_m->get_single_blog_kategori(array('id_blog_kategori' => $id_blog_kategori));

        if (!$res){
            $response['status'] = 'NOK';
            $response['message'] = 'Data tidak ditemukan';
            echo json_encode($response);
            exit;
        }

        /*** deleting image */
        $resblog = $this->blog_m->get_blog(array('id_blog_kategori' => $id_blog_kategori), 0, 0);
        if ($resblog){
            foreach($resblog as $row){
                if ($row->gambar != "" && file_exists($this->data_path.'blog/'.$row->gambar)){
                    unlink($this->data_path.'blog/'.$row->gambar);
                }
            }
        }

        $resdelete = $this->blog_kategori_m->delete_blog_kategori($id_blog_kategori);
        if ($resdelete){

            $response['status'] = 'OK';
            $response['message'] = 'Berhasil menghapus kategori blog';
        }else{
            $response['status'] = 'NOK';
            $response['message'] = 'Gagal menghapus kategori blog';
        }
        
        echo json_encode($response);

        exit;
    }

    public function delete_all(){
        header("Content-type: text/json");

        if (count($_POST['items'])>0){
            foreach($_POST['items'] as $val){
                $this->blog_kategori_m->delete_blog_kategori($val);
            }
        }

        $response['status'] = 'OK';
        $response['message'] = 'Berhasil menghapus Kategori Blog';

        echo json_encode($response);
        exit;
    }

}