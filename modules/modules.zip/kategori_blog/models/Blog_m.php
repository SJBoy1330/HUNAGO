<?php if(!defined('BASEPATH')) exit('No direct script allowed');

class Blog_m extends MY_Model{

  	protected $_table_name = 'blog';
    protected $_primary_key = 'id_blog';
    protected $_primary_filter = 'intval';
    protected $_order_by = "tanggal";
    protected $_ascdesc = "desc";
    
    public function __construct() 
	{
		parent::__construct();
	}

	public function get_single_blog($array=NULL){
		$query = parent::get_single($array);
		return $query;
	}

	public function get_blog($array=NULL, $limit=20, $start=0){
		$query = parent::get_order_by($array, $limit, $start);
		return $query;
	}

	public function delete_blog($id){
		return parent::delete($id);
	}

    public function delete_blog_by_kategori($id_blog_kategori){
        $this->db->where('id_blog_kategori', $id_blog_kategori);
        return $this->db->delete($this->_table_name);
    }
}