<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
	<!--begin::Toolbar-->
	<div class="toolbar" id="kt_toolbar">
		<div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
			<?php 
			if (isset($parent) && $parent != ""){
				$arrchild = (isset($arrchild) && is_array($arrchild) ? $arrchild : null);
				echo breadcrumb($parent, $arrchild); 
			}
			?>

			<div class="d-flex align-items-center py-1">
				<div class="me-4">
				</div>
				
			</div>
		</div>
	</div>


	<div class="post d-flex flex-column-fluid" id="kt_post">
		<div id="kt_content_container" class="container">
			<div class="card shadow-sm" id="card">
                <div class="card-header">
					<div class="card-toolbar">
						<a href="<?=site_url('kategori_blog')?>" class="btn btn-light btn-sm">
							<i class="bi bi-arrow-left"></i> Batal
						</a>
					</div>
				</div>
                <?php echo form_open(); ?>
                <input type="hidden" name="id_blog_kategori" id="id_blog_kategori" value="<?=$result->id_blog_kategori?>">
                    <div class="card-body">
                        <div class="row mb-3">
                            <label for="nama" class="col-sm-2 col-12 col-form-label">Nama Kategori <span class="text-danger">*</span></label>
                            <!--end::Label-->
                            <div class="col-sm-10 col-12">
                                <input type="text" class="form-control" id="nama" name="nama" required value="<?=$result->nama?>" />
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">

                        <div class="text-center">

                            <button type="submit" id="submit_kategori_blog" class="btn btn-sm btn-success">
                                <span class="indicator-label"><i class="bi bi-check-lg"></i> Simpan</span>
                                <span class="indicator-progress">Please wait...
                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                        </div>

                    </div>

                <?php echo form_close(); ?>
            </div>
		</div>
	
	</div>
</div>
