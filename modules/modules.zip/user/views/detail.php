<div class="row mb-7">
	<!--begin::Label-->
	<label for="username" class="col-sm-4 col-12 text-muted">
		Username
	</label>
	<!--end::Label-->
	<div class="col-sm-8 col-12">
		<div class="fw-bolder fs-6 text-gray-800"><?=$result->username?></div>
	</div>
</div>
<div class="row mb-7">
	<!--begin::Label-->
	<label for="nama" class="col-sm-4 col-12 text-muted">
		Nama
	</label>
	<!--end::Label-->
	<div class="col-sm-8 col-12">
		<div class="fw-bolder fs-6 text-gray-800"><?=$result->nama?></div>
	</div>
</div>

<div class="row mb-7">
	<!--begin::Label-->
	<label for="alamat" class="col-sm-4 col-12 text-muted">
		Alamat
	</label>
	<!--end::Label-->
	<div class="col-sm-8 col-12">
		<div class="fw-bolder fs-6 text-gray-800"><?=$result->alamat?></div>
	</div>
</div>
<div class="row mb-7">
	<!--begin::Label-->
	<label for="telp" class="col-sm-4 col-12 text-muted">
		Telp
	</label>
	<!--end::Label-->
	<div class="col-sm-8 col-12">
		<div class="fw-bolder fs-6 text-gray-800"><?=$result->telp?></div>
	</div>
</div>
<div class="row mb-7">
	<!--begin::Label-->
	<label for="email" class="col-sm-4 col-12 text-muted">
		Email
	</label>
	<!--end::Label-->
	<div class="col-sm-8 col-12">
		<div class="fw-bolder fs-6 text-gray-800"><?=$result->email?></div>
	</div>
</div>
