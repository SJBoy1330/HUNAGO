<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Backend_ctl extends MY_Admin {

    protected $mydata;

    var $data_path = "";

    function __construct(){
        parent::__construct();

        if (!$this->oitocauth->is_loggedin()){
            redirect(site_url('auth'));
        }

        $this->load->model('klien_m');
        $this->load->model('transaksi_m');
        $this->data_path = $this->config->item('data_path');
    }

    public function index(){

        $this->data['pagetitle'] = "Transaksi"; 

        $mydata['parent'] = 'Transaksi';
        $mydata['arrchild'][] = array('link' => site_url('dashboard'), 'name' => 'Dashboard');
        $mydata['arrchild'][] = array('link' => '#', 'name' => 'Transaksi');

        $this->data['css_add'][] = '<link href="'.base_url('assets/dist/assets/plugins/custom/datatables/datatables.bundle.css').'" rel="stylesheet" type="text/css" />';

        $this->data['js_add'][] = '<script src="'.base_url('assets/dist/assets/plugins/custom/datatables/datatables.bundle.js').'"></script>';

        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/js/page/transaksi/transaksi.js').'"></script>';

        $result = $this->transaksi_m->get_transaksi('',0,0);
        $mydata['result'] = $result;

        $resklien = $this->klien_m->get_klien('',0,0);
        $mydata['resklien'] = $resklien;

        $arrKlien = [];
        if ($resklien){
            foreach($resklien as $row){
                $arrKlien[$row->id_klien] = $row->nama;
            }
        }
        $mydata['arrKlien'] = $arrKlien;

        $mydata['data_path'] = $this->data_path;

        $this->data['content']=$this->load->view('index',$mydata,true);

        $this->display();
    }

    public function add(){

        $this->data['pagetitle'] = "Tambah Transaksi"; 

        $mydata['parent'] = 'Tambah Transaksi';
        $mydata['arrchild'][] = array('link' => site_url('dashboard'), 'name' => 'Dashboard');
        $mydata['arrchild'][] = array('link' => site_url('Transaksi'), 'name' => 'Transaksi');
        $mydata['arrchild'][] = array('link' => '#', 'name' => 'Tambah Transaksi');

        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/js/page/transaksi/add_transaksi.js').'"></script>';

        $resklien = $this->klien_m->get_klien('',0,0);
        $mydata['resklien'] = $resklien;

        $mydata['data_path'] = $this->data_path;

        $this->data['content']=$this->load->view('add',$mydata,true);

        $this->display();
    }

    public function save_add(){

        header("Content-type: text/json");

        $arrVar = array('tanggal', 'nama_project', 'tanggal', 'id_klien', 'status', 'total');
        foreach($arrVar as $var){
            $$var = $this->input->post($var);
        }

        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required', array('required' => 'Tanggal harus diisi'));
        $this->form_validation->set_rules('nama_project', 'Nama Proyek', 'required', array('required' => 'Tanggal harus diisi'));
        $this->form_validation->set_rules('id_klien', 'Klien', 'required', array('required' => 'Klien harus diisi'));
        $this->form_validation->set_rules('total', 'Total', 'required', array('required' => 'Total harus diisi'));
        $this->form_validation->set_rules('status', 'Status', 'required', array('required' => 'Status harus diisi'));

        if ($this->form_validation->run() === FALSE){
            $response['status'] = 'NOK';
            $response['message'] = validation_errors();
            echo json_encode($response);
            exit;
        }

        $arrInsert['status'] = $nama;
        $arrInsert['id_klien'] = $id_klien;
        $arrInsert['nama_project'] = $nama_project;
        $arrInsert['total'] = $total;
        $arrInsert['tanggal'] = reverse_date($tanggal);
        $arrInsert['status'] = $status;

        if ($this->transaksi_m->insert_transaksi($arrInsert)){
            $response['status'] = 'OK';
            $response['message'] = 'Berhasil menambahkan Transaksi';
        }else{
            $response['status'] = 'NOK';
            $response['message'] = 'Gagal menambahkan Transaksi';
        }
        echo json_encode($response);
        exit;

    }

    public function edit(){
        
        $this->data['pagetitle'] = "Update Transaksi"; 

        $id_transaksi = $this->uri->segment(3);

        $mydata['parent'] = 'Update Transaksi';
        $mydata['arrchild'][] = array('link' => site_url('dashboard'), 'name' => 'Dashboard');
        $mydata['arrchild'][] = array('link' => site_url('transaksi'), 'name' => 'Transaksi');
        $mydata['arrchild'][] = array('link' => '#', 'name' => 'Update Transaksi');

        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/js/page/transaksi/edit_transaksi.js').'"></script>';

        $result = $this->transaksi_m->get_single_transaksi(array('id_transaksi' => $id_transaksi));
        $mydata['result'] = $result;

        $resklien = $this->klien_m->get_klien('', 0, 0);
        $mydata['resklien'] = $resklien;

        $mydata['data_path'] = $this->data_path;

        $this->data['content']=$this->load->view('edit',$mydata,true);

        $this->display();
    }

    public function save_edit(){
        
        header("Content-type: text/json");

        $arrVar = array('id_transaksi', 'tanggal', 'nama_project', 'tanggal', 'id_klien', 'status', 'total');
        foreach($arrVar as $var){
            $$var = $this->input->post($var);
        }

        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required', array('required' => 'Tanggal harus diisi'));
        $this->form_validation->set_rules('nama_project', 'Nama Proyek', 'required', array('required' => 'Tanggal harus diisi'));
        $this->form_validation->set_rules('id_klien', 'Klien', 'required', array('required' => 'Klien harus diisi'));
        $this->form_validation->set_rules('total', 'Total', 'required', array('required' => 'Total harus diisi'));
        $this->form_validation->set_rules('status', 'Status', 'required', array('required' => 'Status harus diisi'));

        if ($this->form_validation->run() === FALSE){
            $response['status'] = 'NOK';
            $response['message'] = validation_errors();
            echo json_encode($response);
            exit;
        }

        $arrUpdate['status'] = $nama;
        $arrUpdate['id_klien'] = $id_klien;
        $arrUpdate['nama_project'] = $nama_project;
        $arrUpdate['total'] = $total;
        $arrUpdate['tanggal'] = reverse_date($tanggal);
        $arrUpdate['status'] = $status;

        if ($this->transaksi_m->update_transaksi($arrUpdate, $id_transaksi)){
            $response['status'] = 'OK';
            $response['message'] = 'Berhasil mengubah Transaksi';
        }else{
            $response['status'] = 'NOK';
            $response['message'] = 'Gagal mengubah Transaksi';
        }

        echo json_encode($response);

        exit;
    }

    public function detail(){

        $id_transaksi = $this->input->post('id_transaksi');

        $result = $this->transaksi_m->get_single_transaksi(array('id_transaksi' => $id_transaksi));

        $data['result'] = $result;

        $this->load->view('detail', $data);
    }

    public function delete(){
        header("Content-type: text/json");

        $id_transaksi = $this->input->post('id_transaksi');

        $res = $this->transaksi_m->get_single_transaksi(array('id_transaksi' => $id_transaksi));

        if (!$res){
            $response['status'] = 'NOK';
            $response['message'] = 'Data tidak ditemukan';
            echo json_encode($response);
            exit;
        }

        $resdelete = $this->transaksi_m->delete_transaksi($id_transaksi);
        if ($resdelete){
            $response['status'] = 'OK';
            $response['message'] = 'Berhasil menghapus Transaksi';
        }else{
            $response['status'] = 'NOK';
            $response['message'] = 'Gagal menghapus Transaksi';
        }
        
        echo json_encode($response);

        exit;
    }

    public function delete_all(){
        header("Content-type: text/json");

        if (count($_POST['items'])>0){
            foreach($_POST['items'] as $val){
                $res = $this->transaksi_m->get_single_transaksi(array('id_transaksi' => $val));

                $this->transaksi_m->delete_transaksi($val);
            }
        }

        $response['status'] = 'OK';
        $response['message'] = 'Berhasil menghapus Transaksi';

        echo json_encode($response);
        exit;
    }

}