<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
	<!--begin::Toolbar-->
	<div class="toolbar" id="kt_toolbar">
		<div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
			<?php 
			if (isset($parent) && $parent != ""){
				$arrchild = (isset($arrchild) && is_array($arrchild) ? $arrchild : null);
				echo breadcrumb($parent, $arrchild); 
			}
			?>

			<div class="d-flex align-items-center py-1">
				<div class="me-4">
				</div>
				
			</div>
		</div>
	</div>


	<div class="post d-flex flex-column-fluid" id="kt_post">
		<div id="kt_content_container" class="container">
			<div class="card shadow-sm" id="card">
                <div class="card-header">
					<div class="card-toolbar">
						<a href="<?=site_url('transaksi')?>" class="btn btn-light btn-sm">
							<i class="bi bi-arrow-left"></i> Batal
						</a>
					</div>
				</div>
                <?php echo form_open(); ?>
                    <input type="hidden" name="id_transaksi" id="id_transaksi" value="<?=$result->id_transaksi?>">
                    <div class="card-body">
                        
                        <div class="row mb-3">
                            <label for="tanggal" class="col-sm-2 col-12 col-form-label">Tanggal <span class="text-danger">*</span></label>
                            <!--end::Label-->
                            <div class="col-sm-10 col-12">
                                <input type="text" name="tanggal" id="tanggal" value="<?=$result->tanggal?>" class="form-control" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="id_klien" class="col-sm-2 col-12 col-form-label">Klien <span class="text-danger">*</span></label>
                            <!--end::Label-->
                            <div class="col-sm-10 col-12">
                                <select name="id_klien" id="id_klien" class="form-select form-select-sm" data-placeholder="Pilih" data-kt-select2="true">
                                    <option value="">Pilih</option>
                                    <?php if ($resklien): ?>
                                        <?php foreach($resklien as $row): ?>
                                            <option value="<?=$row->id_klien?>" <?=($row->id_klien == $result->id_klien) ? "selected": ""?>><?=$row->nama?></option>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="nama_project" class="col-sm-2 col-12 col-form-label">Nama Project <span class="text-danger">*</span></label>
                            <!--end::Label-->
                            <div class="col-sm-10 col-12">
                                <input type="text" name="nama_project" id="nama_project" class="form-control" value="<?=$result->nama_project?>" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="total" class="col-sm-2 col-12 col-form-label">Total <span class="text-danger">*</span></label>
                            <!--end::Label-->
                            <div class="col-sm-10 col-12">
                                <input type="number" name="total" id="total" class="form-control" value="<?=$result->total?>" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="status" class="col-sm-2 col-12 col-form-label">Status <span class="text-danger">*</span></label>
                            <!--end::Label-->
                            <div class="col-sm-10 col-12">
                                <select name="status" id="status" class="form-select form-select-sm" data-kt-select2="true">
                                    <option value="0" <?=($result->status === "0") ? "selected": ""?>>Baru</option>
                                    <option value="1" <?=($result->status == "1") ? "selected": ""?>>Diproses</option>
                                    <option value="2" <?=($result->status == "2") ? "selected": ""?>>Selesai</option>
                                    <option value="3" <?=($result->status == "3") ? "selected": ""?>>Batal</option>
                                </select>
                            </div>
                        </div>
                        
                    </div>
                    <div class="card-footer">

                        <div class="text-center">

                            <button type="submit" id="submit_transaksi" class="btn btn-sm btn-success">
                                <span class="indicator-label"><i class="bi bi-check-lg"></i> Simpan</span>
                                <span class="indicator-progress">Please wait...
                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                        </div>

                    </div>

                <?php echo form_close(); ?>
            </div>
		</div>
	
	</div>
</div>
