<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Backend_ctl extends MY_Admin {

    protected $mydata;

    var $data_path = "";

    function __construct(){
        parent::__construct();

        if (!$this->oitocauth->is_loggedin()){
            redirect(site_url('auth'));
        }

        $this->load->model('klien_m');
        $this->data_path = $this->config->item('data_path');
    }

    public function index(){

        $this->data['pagetitle'] = "Klien"; 

        $mydata['parent'] = 'Klien';
        $mydata['arrchild'][] = array('link' => site_url('dashboard'), 'name' => 'Dashboard');
        $mydata['arrchild'][] = array('link' => '#', 'name' => 'Klien');

        $this->data['css_add'][] = '<link href="'.base_url('assets/dist/assets/plugins/custom/datatables/datatables.bundle.css').'" rel="stylesheet" type="text/css" />';

        $this->data['js_add'][] = '<script src="'.base_url('assets/dist/assets/plugins/custom/datatables/datatables.bundle.js').'"></script>';

        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/js/page/klien/klien.js').'"></script>';

        $result = $this->klien_m->get_klien('',0,0);
        $mydata['result'] = $result;

        $mydata['data_path'] = $this->data_path;

        $this->data['content']=$this->load->view('index',$mydata,true);

        $this->display();
    }

    public function add(){

        $this->data['pagetitle'] = "Tambah Klien"; 

        $mydata['parent'] = 'Tambah Klien';
        $mydata['arrchild'][] = array('link' => site_url('dashboard'), 'name' => 'Dashboard');
        $mydata['arrchild'][] = array('link' => site_url('klien'), 'name' => 'Klien');
        $mydata['arrchild'][] = array('link' => '#', 'name' => 'Tambah Klien');

        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/js/page/klien/add_klien.js').'"></script>';

        $result = $this->klien_m->get_klien('',0,0);
        $mydata['result'] = $result;

        $mydata['data_path'] = $this->data_path;

        $this->data['content']=$this->load->view('add',$mydata,true);

        $this->display();
    }

    public function save_add(){

        header("Content-type: text/json");

        $arrVar = array('nama', 'alamat', 'telp', 'email');
        foreach($arrVar as $var){
            $$var = $this->input->post($var);
        }

        $this->form_validation->set_rules('nama', 'Nama', 'required', array('required' => 'Nama harus diisi'));
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email', array('required' => 'Email harus diisi', 'valid_email' => 'Format email harus sesuai'));
        $this->form_validation->set_rules('telp', 'Telp', 'required', array('required' => 'Telp harus diisi'));
        $this->form_validation->set_rules('alamat', 'Alamat', 'required', array('required' => 'Alamat harus diisi'));

        if ($this->form_validation->run() === FALSE){
            $response['status'] = 'NOK';
            $response['message'] = validation_errors();
            echo json_encode($response);
            exit;
        }

        $klien = $this->klien_m->get_single_klien(array('email' => $email));
        if ($klien){
            $response['status'] = "NOK";
            $response['message'] = "Email sudah dipakai";
            echo json_encode($response);
            exit;
        }

        $klien = $this->klien_m->get_single_klien(array('telp' => $telp));
        if ($klien){
            $response['status'] = "NOK";
            $response['message'] = "Telp sudah dipakai";
            echo json_encode($response);
            exit;
        }

        if (!empty($_FILES['logo']['tmp_name'])){
            $config['upload_path'] = $this->data_path.'klien';
            $config['allowed_types'] = '*';
            $config['file_name'] = uniqid();
            $config['file_ext_tolower'] = true;
        
            $this->load->library('upload', $config);

            $data=[];

            if (! $this->upload->do_upload('logo')){
                $error = array('error' => $this->upload->display_errors());
                $response['status'] = 'NOK';
                $response['message'] = 'Gagal mengupload file: '.$error['error'];//.$error['error'].' '.$_FILES['gambar']['type'];
                echo json_encode($response);
                exit;
            }else{

                $data = array('upload_data' => $this->upload->data());

            }

            $foto = $data['upload_data']['file_name'];
            $arrInsert['logo'] = $foto;
        }else{
            $response['status'] = "NOK";
            $response['message'] = 'File Gambar masih kosong';
            echo json_encode($response);
            exit;
        }

        $arrInsert['nama'] = $nama;
        $arrInsert['alamat'] = $alamat;
        $arrInsert['telp'] = $telp;
        $arrInsert['email'] = $email;

        if ($this->klien_m->insert_klien($arrInsert)){
            $response['status'] = 'OK';
            $response['message'] = 'Berhasil menambahkan Klien';
        }else{
            $response['status'] = 'NOK';
            $response['message'] = 'Gagal menambahkan Klien';
        }
        echo json_encode($response);
        exit;

    }

    public function edit(){
        
        $this->data['pagetitle'] = "Update Klien"; 

        $id_klien = $this->uri->segment(3);

        $mydata['parent'] = 'Update klien';
        $mydata['arrchild'][] = array('link' => site_url('dashboard'), 'name' => 'Dashboard');
        $mydata['arrchild'][] = array('link' => site_url('klien'), 'name' => 'Klien');
        $mydata['arrchild'][] = array('link' => '#', 'name' => 'Update Klien');

        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/js/page/klien/edit_klien.js').'"></script>';

        $result = $this->klien_m->get_single_klien(array('id_klien' => $id_klien));
        $mydata['result'] = $result;

        $mydata['data_path'] = $this->data_path;

        $this->data['content']=$this->load->view('edit',$mydata,true);

        $this->display();
    }

    public function save_edit(){
        
        header("Content-type: text/json");

        $arrVar = array('id_klien', 'nama', 'alamat', 'telp', 'email');
        foreach($arrVar as $var){
            $$var = $this->input->post($var);
        }

        $this->form_validation->set_rules('nama', 'Nama', 'required', array('required' => 'Nama harus diisi'));
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email', array('required' => 'Email harus diisi', 'valid_email' => 'Format email harus sesuai'));
        $this->form_validation->set_rules('telp', 'Telp', 'required', array('required' => 'Telp harus diisi'));
        $this->form_validation->set_rules('alamat', 'Alamat', 'required', array('required' => 'Alamat harus diisi'));

        if ($this->form_validation->run() === FALSE){
            $response['status'] = 'NOK';
            $response['message'] = validation_errors();
            echo json_encode($response);
            exit;
        }

        $klien = $this->klien_m->get_single_klien(array('email' => $email));
        if ($klien){
            if ($klien->id_klien != $id_klien){
                $response['status'] = "NOK";
                $response['message'] = "Email sudah dipakai";
                echo json_encode($response);
                exit;
            }
        }

        $klien = $this->klien_m->get_single_klien(array('telp' => $telp));
        if ($klien){
            if ($klien->id_klien != $id_klien){
                $response['status'] = "NOK";
                $response['message'] = "Telp sudah dipakai";
                echo json_encode($response);
                exit;
            }
        }

        if (!empty($_FILES['logo']['tmp_name'])){
            $config['upload_path'] = $this->data_path.'klien';
            $config['allowed_types'] = '*';
            $config['file_name'] = uniqid();
            $config['file_ext_tolower'] = true;
        
            $this->load->library('upload', $config);

            $data=[];

            if (! $this->upload->do_upload('logo')){
                $error = array('error' => $this->upload->display_errors());
                $response['status'] = 'NOK';
                $response['message'] = 'Gagal mengupload file: '.$error['error'];//.$error['error'].' '.$_FILES['gambar']['type'];
                echo json_encode($response);
                exit;
            }else{

                if ($klien->logo != "" && file_exists($this->data_path.'klien/'.$klien->logo)){
                    unlink($this->data_path.'klien/'.$klien->logo);
                }

                $data = array('upload_data' => $this->upload->data());

            }

            $foto = $data['upload_data']['file_name'];
            $arrUpdate['logo'] = $foto;
        }

        $arrUpdate['nama'] = $nama;
        $arrUpdate['alamat'] = $alamat;
        $arrUpdate['telp'] = $telp;
        $arrUpdate['email'] = $email;

        if ($this->klien_m->update_klien($arrUpdate, $id_klien)){
            $response['status'] = 'OK';
            $response['message'] = 'Berhasil mengubah Klien';
        }else{
            $response['status'] = 'NOK';
            $response['message'] = 'Gagal mengubah Klien';
        }

        echo json_encode($response);

        exit;
    }

    public function delete(){
        header("Content-type: text/json");

        $id_klien = $this->input->post('id_klien');

        $res = $this->klien_m->get_single_klien(array('id_klien' => $id_klien));

        if (!$res){
            $response['status'] = 'NOK';
            $response['message'] = 'Data tidak ditemukan';
            echo json_encode($response);
            exit;
        }

        $resdelete = $this->klien_m->delete_klien($id_klien);
        if ($resdelete){

            if ($res->logo != '' && file_exists($this->data_path.'klien/'.$res->logo)){
                unlink($this->data_path.'klien/'.$res->logo);
            }

            $response['status'] = 'OK';
            $response['message'] = 'Berhasil menghapus Klien';
        }else{
            $response['status'] = 'NOK';
            $response['message'] = 'Gagal menghapus Klien';
        }
        
        echo json_encode($response);

        exit;
    }

    public function delete_all(){
        header("Content-type: text/json");

        if (count($_POST['items'])>0){
            foreach($_POST['items'] as $val){
                $res = $this->klien_m->get_single_klien(array('id_klien' => $val));

                $logo = $res->logo;

                if ($logo != '' && file_exists($this->data_path.'klien/'.$logo)){
                    unlink($this->data_path.'klien/'.$logo);
                }
                
                $this->klien_m->delete_klien($val);
            }
        }

        $response['status'] = 'OK';
        $response['message'] = 'Berhasil menghapus Klien';

        echo json_encode($response);
        exit;
    }

}