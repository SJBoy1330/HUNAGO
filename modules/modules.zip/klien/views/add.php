<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
	<!--begin::Toolbar-->
	<div class="toolbar" id="kt_toolbar">
		<div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
			<?php 
			if (isset($parent) && $parent != ""){
				$arrchild = (isset($arrchild) && is_array($arrchild) ? $arrchild : null);
				echo breadcrumb($parent, $arrchild); 
			}
			?>

			<div class="d-flex align-items-center py-1">
				<div class="me-4">
				</div>
				
			</div>
		</div>
	</div>


	<div class="post d-flex flex-column-fluid" id="kt_post">
		<div id="kt_content_container" class="container">
			<div class="card shadow-sm" id="card">
                <div class="card-header">
					<div class="card-toolbar">
						<a href="<?=site_url('klien')?>" class="btn btn-light btn-sm">
							<i class="bi bi-arrow-left"></i> Batal
						</a>
					</div>
				</div>
                <?php echo form_open(); ?>
                    
                    <div class="card-body">
                        
                        <div class="row mb-3">
                            <label for="nama" class="col-sm-2 col-12 col-form-label">Nama <span class="text-danger">*</span></label>
                            <!--end::Label-->
                            <div class="col-sm-10 col-12">
                                <input type="text" name="nama" id="nama" class="form-control" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="alamat" class="col-sm-2 col-12 col-form-label">Alamat <span class="text-danger">*</span></label>
                            <!--end::Label-->
                            <div class="col-sm-10 col-12">
                                <textarea name="alamat" id="alamat" class="form-control"></textarea>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="telp" class="col-sm-2 col-12 col-form-label">Telp <span class="text-danger">*</span></label>
                            <!--end::Label-->
                            <div class="col-sm-10 col-12">
                                <input type="text" name="telp" id="telp" class="form-control" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="email" class="col-sm-2 col-12 col-form-label">Email <span class="text-danger">*</span></label>
                            <!--end::Label-->
                            <div class="col-sm-10 col-12">
                                <input type="email" name="email" id="email" class="form-control" required>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
						    <label for="logo" class="col-sm-2 col-12 col-form-label">Logo <span class="text-danger">*</span></label>
						    <!--end::Label-->
						<div class="col-sm-10 col-12">
                            <div class="image-input image-input-outline " data-kt-image-input="true" style="background-image: url(<?=site_url('media/no_image')?>)">
								     <!--begin::Image preview wrapper-->
								     <div class="image-input-wrapper w-125px h-125px" style="background-image: url(<?=site_url('media/no_image')?>)"></div>
								     <!--end::Image preview wrapper-->

								     <!--begin::Edit button-->
								     <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-kt-image-input-action="change" data-bs-toggle="tooltip" data-bs-dismiss="click" title="" data-bs-original-title="Tambah Gambar">
								         <i class="bi bi-pencil-fill fs-7"></i>

								         <!--begin::Inputs-->
								         <input type="file" name="logo" accept=".png, .jpg, .jpeg">
								         <input type="hidden" name="foto_remove">
								         <!--end::Inputs-->
								     </label>
								     <!--end::Edit button-->

								     <!--begin::Cancel button-->
								     <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-kt-image-input-action="cancel" data-bs-toggle="tooltip" data-bs-dismiss="click" title="" data-bs-original-title="Batal">
								         <i class="bi bi-x fs-2"></i>
								     </span>
								     <!--end::Cancel button-->

								     <!--begin::Remove button-->
								     <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-kt-image-input-action="remove" data-bs-toggle="tooltip" data-bs-dismiss="click" title="" data-bs-original-title="Hapus foto">
								         <i class="bi bi-x fs-2"></i>
								     </span>
								     <!--end::Remove button-->
								 </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">

                        <div class="text-center">

                            <button type="submit" id="submit_klien" class="btn btn-sm btn-success">
                                <span class="indicator-label"><i class="bi bi-check-lg"></i> Simpan</span>
                                <span class="indicator-progress">Please wait...
                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                        </div>

                    </div>

                <?php echo form_close(); ?>
            </div>
		</div>
	
	</div>
</div>
