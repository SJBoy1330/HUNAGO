<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
	<!--begin::Toolbar-->
	<div class="toolbar" id="kt_toolbar">
		<div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
			<?php 
			if (isset($parent) && $parent != ""){
				$arrchild = (isset($arrchild) && is_array($arrchild) ? $arrchild : null);
				echo breadcrumb($parent, $arrchild); 
			}
			?>

			<div class="d-flex align-items-center py-1">
				<div class="me-4">

				
					<a href="<?=site_url('klien/add')?>" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i> Klien</a>
				</div>
				
			</div>
		</div>
	</div>


	<div class="post d-flex flex-column-fluid" id="kt_post">
		<div id="kt_content_container" class="container">
			<div class="card shadow-sm" id="card">

            <div class="card-header">
					<div class="card-toolbar">
			            <button type="button" class="btn btn-danger btn-sm" id="btn_delete_selected" disabled="disabled"><i class="bi bi-trash"></i> Hapus</button>
			        </div>
				</div>
			<div class="card-body">

				<table class="table table-bordered table-striped table-rounded table-hover gs-7 gy-7 gx-7 DataTable no-footer" id="kt_table_klien">
					<thead>
						<!--begin::Table row-->
						<tr role="row">
                            <th class="w-10px pe-2">
                                <div class="form-check form-check-sm form-check-custom form-check-solid me-3">
                                    <input class="form-check-input" type="checkbox" data-kt-check="true" data-kt-check-target="#kt_table_klien .form-check-input" id="button_check_all" value="1" />
                                </div>
                            </th>
							<th class="w-10px text-center"><i class="fa fa-bars fs-4"></i></th>
							<th class="w-125px text-center">NO</th>
							<th class="min-w-125px text-center text-uppercase">Nama Klien</th>
							<th class="min-w-125px text-center text-uppercase">Logo</th>
							<th class="min-w-125px text-center text-uppercase">Email</th>
							<th class="min-w-125px text-center text-uppercase">Telp</th>
							<th class="min-w-125px text-center text-uppercase">Alamat</th>
						</tr>
						<!--end::Table row-->
					</thead>
					<tbody>
						<?php if ($result):
							$no = 1;
						 ?>
							<?php foreach($result as $row): ?>
								<tr>
                                    <td>
                                        <div class="form-check form-check-sm form-check-custom form-check-solid">
                                            <input class="form-check-input checkboxes" type="checkbox" name="items[]" value="<?=$row->id_klien?>" />
                                        </div>
                                    </td>   
									<td class="text-center">
									
										<button type="button" class="btn btn-sm btn-primary btn-icon fs-10" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-start" data-kt-menu-flip="top-start">
											<i class="fa fa-bars fs-4"></i>
										</button>
										<div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg-light-primary fw-bold w-200px" data-kt-menu="true">
											<div class="menu-item px-3 my-2">
												<a href="<?=site_url('klien/edit/'.$row->id_klien)?>" class="menu-link px-3">Edit</a>
											</div>
											<div class="menu-item px-3 my-2">
												<a href="#" class="menu-link px-3 btn_delete" data-bs-toggle="modal" data-bs-target="#modal_delete" data-bs-nama="<?=$row->nama?>" data-bs-id_klien="<?=$row->id_klien?>">Hapus</a>
											</div>
										</div>

									</td>
									<td class="text-center"></td>
									<td><?=$row->nama?></td>
									<td class="text-center"><?php 
                                         if ($row->logo != "" && file_exists($this->data_path.'klien/'.$row->logo)){
                                            $encimg = setencrypt($row->logo);
                                            $url = site_url('media/image_access_klien/'.$encimg);
                                        }else{
                                            $url = site_url('media/no_image');
                                        }
                                    ?>
                                    <img src="<?=$url?>" width="50">
                                    </td>
                                    <td><?=$row->email?></td>
                                    <td><?=htmlspecialchars($row->telp)?></td>
                                    <td><?=htmlspecialchars($row->alamat)?></td>
								</tr>
							<?php 
							$no++;
							endforeach; ?>
						<?php endif; ?>

					</tbody>
				</table>
			</div>
            </div>
		</div>
	
	</div>
</div>

<div class="modal fade" id="modal_delete" tabindex="-1" role="basic" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Konfirmasi</h4>
				<div class="btn btn-icon btn-sm btn-active-light-primary ms-2" data-bs-dismiss="modal" aria-label="Close">
                    <i class="fa fa-times fs-4"></i>
                </div>
			</div>
			<div class="modal-body">Anda yakin akan menghapus Klien [<span id="nama"></span>]? Aksi ini tidak bisa dibatalkan.
				<input type="hidden" id="id_klien" name="id_klien">
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-light" data-bs-dismiss="modal"> Batal</button>
				<button type="button" id="btn_delete_confirm" class="btn btn-danger">Ya</button>
			</div>
		</div>
	</div>
</div>


<div class="modal fade" id="modal_delete_selected" tabindex="-1" role="basic" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Konfirmasi</h4>
				<div class="btn btn-icon btn-sm btn-active-light-primary ms-2" data-bs-dismiss="modal" aria-label="Close">
                    <i class="fa fa-times fs-4"></i>
                </div>
			</div>
			<div class="modal-body">Anda yakin akan menghapus <span id="jumlahklien"></span> data klien terpilih? Aksi ini tidak bisa dibatalkan.
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-light" data-bs-dismiss="modal"> Batal</button>
				<button type="button" id="btn_delete_all_confirm" class="btn btn-danger">Ya</button>
			</div>
		</div>
	</div>
</div>