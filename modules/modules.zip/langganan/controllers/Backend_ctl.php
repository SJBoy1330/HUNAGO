<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Backend_ctl extends MY_Admin {

    protected $mydata;

    var $data_path = "";

    function __construct(){
        parent::__construct();

        if (!$this->oitocauth->is_loggedin()){
            redirect(site_url('auth'));
        }

        $this->load->model('langganan_m');
        $this->data_path = $this->config->item('data_path');
    }

    public function index(){

        $this->data['pagetitle'] = "Langganan"; 

        $mydata['parent'] = 'Langganan';
        $mydata['arrchild'][] = array('link' => site_url('dashboard'), 'name' => 'Dashboard');
        $mydata['arrchild'][] = array('link' => '#', 'name' => 'Langganan');

        $this->data['css_add'][] = '<link href="'.base_url('assets/dist/assets/plugins/custom/datatables/datatables.bundle.css').'" rel="stylesheet" type="text/css" />';

        $this->data['js_add'][] = '<script src="'.base_url('assets/dist/assets/plugins/custom/datatables/datatables.bundle.js').'"></script>';

        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/js/page/langganan/langganan.js').'"></script>';

        $result = $this->langganan_m->get_langganan('',0,0);
        $mydata['result'] = $result;

        $mydata['data_path'] = $this->data_path;

        $this->data['content']=$this->load->view('index',$mydata,true);

        $this->display();
    }

    

    public function delete(){
        header("Content-type: text/json");

        $id_langganan = $this->input->post('id_langganan');

        $res = $this->langganan_m->get_single_langganan(array('id_langganan' => $id_langganan));

        if (!$res){
            $response['status'] = 'NOK';
            $response['message'] = 'Data tidak ditemukan';
            echo json_encode($response);
            exit;
        }

        $resdelete = $this->langganan_m->delete_langganan($id_langganan);
        if ($resdelete){

            $response['status'] = 'OK';
            $response['message'] = 'Berhasil menghapus Langganan';
        }else{
            $response['status'] = 'NOK';
            $response['message'] = 'Gagal menghapus Langganan';
        }
        
        echo json_encode($response);

        exit;
    }

    public function delete_all(){
        header("Content-type: text/json");

        if (count($_POST['items'])>0){
            foreach($_POST['items'] as $val){               
                $this->langganan_m->delete_langganan($val);
            }
        }

        $response['status'] = 'OK';
        $response['message'] = 'Berhasil menghapus Langganan';

        echo json_encode($response);
        exit;
    }

}