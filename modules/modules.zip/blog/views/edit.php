<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
	<!--begin::Toolbar-->
	<div class="toolbar" id="kt_toolbar">
		<div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
			<?php 
			if (isset($parent) && $parent != ""){
				$arrchild = (isset($arrchild) && is_array($arrchild) ? $arrchild : null);
				echo breadcrumb($parent, $arrchild); 
			}
			?>

			<div class="d-flex align-items-center py-1">
				<div class="me-4">
				</div>
				
			</div>
		</div>
	</div>


	<div class="post d-flex flex-column-fluid" id="kt_post">
		<div id="kt_content_container" class="container">
			<div class="card shadow-sm" id="card">
                <div class="card-header">
					<div class="card-toolbar">
						<a href="<?=site_url('blog')?>" class="btn btn-light btn-sm">
							<i class="bi bi-arrow-left"></i> Batal
						</a>
					</div>
				</div>
                <?php echo form_open(); ?>
                    <input type="hidden" name="id_blog" id="id_blog" value="<?=$result->id_blog?>">
                    <div class="card-body">
                        
                        <div class="row mb-3">
                            <label for="id_blog_kategori" class="col-sm-2 col-12 col-form-label">Kategori <span class="text-danger">*</span></label>
                            <!--end::Label-->
                            <div class="col-sm-10 col-12">
                                <select name="id_blog_kategori" id="id_blog_kategori" class="form-select form-select-sm" data-kt-select2="true" data-placeholder="Pilih" data-allow-clear="true" required>
                                    <option value="">Pilih</option>
                                    <?php if ($reskategori): ?>
                                        <?php foreach($reskategori as $row): ?>
                                            <option value="<?=$row->id_blog_kategori?>" <?=($row->id_blog_kategori == $result->id_blog_kategori) ? "selected" : ""?>><?=$row->nama?></option>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <label for="judul" class="col-sm-2 col-12 col-form-label">Judul <span class="text-danger">*</span></label>
                            <!--end::Label-->
                            <div class="col-sm-10 col-12">
                                <input type="text" name="judul" id="judul" class="form-control" value="<?=$result->judul?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
						    <label for="gambar" class="col-sm-2 col-12 col-form-label">Gambar <span class="text-danger">*</span></label>
						    <!--end::Label-->
						<div class="col-sm-10 col-12">
                            <div class="image-input image-input-outline " data-kt-image-input="true" style="background-image: url(<?=site_url('media/no_image')?>)">
								     <!--begin::Image preview wrapper-->
                                     <?php 
                                        if ($result->gambar != "" && file_exists($this->data_path.'blog/'.$result->gambar)){
                                            $encimg = setencrypt($result->gambar);
                                            $url = site_url('media/image_access_blog/'.$encimg);
                                        }else{
                                            $url = site_url('media/no_image');
                                        }
                                     ?>
								     <div class="image-input-wrapper w-125px h-125px" style="background-image: url(<?=$url?>)"></div>
								     <!--end::Image preview wrapper-->

								     <!--begin::Edit button-->
								     <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-kt-image-input-action="change" data-bs-toggle="tooltip" data-bs-dismiss="click" title="" data-bs-original-title="Tambah Gambar">
								         <i class="bi bi-pencil-fill fs-7"></i>

								         <!--begin::Inputs-->
								         <input type="file" name="gambar" accept=".png, .jpg, .jpeg">
								         <input type="hidden" name="foto_remove">
								         <!--end::Inputs-->
								     </label>
								     <!--end::Edit button-->

								     <!--begin::Cancel button-->
								     <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-kt-image-input-action="cancel" data-bs-toggle="tooltip" data-bs-dismiss="click" title="" data-bs-original-title="Batal">
								         <i class="bi bi-x fs-2"></i>
								     </span>
								     <!--end::Cancel button-->

								     <!--begin::Remove button-->
								     <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-kt-image-input-action="remove" data-bs-toggle="tooltip" data-bs-dismiss="click" title="" data-bs-original-title="Hapus foto">
								         <i class="bi bi-x fs-2"></i>
								     </span>
								     <!--end::Remove button-->
								 </div>
						</div>
					</div>

                        <div class="row mb-3">
                            <label for="detail" class="col-sm-2 col-12 col-form-label">Isi <span class="text-danger">*</span></label>
                            <!--end::Label-->
                            <div class="col-sm-10 col-12">
                                <textarea class="form-control form-control-flush mb-3" rows="1" data-kt-element="input" name="detail" id="detail" placeholder="Ketik keterangan"><?=$result->detail?></textarea>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="tanggal" class="col-sm-2 col-12 col-form-label">Tanggal Publish <span class="text-danger">*</span></label>
                            <!--end::Label-->
                            <div class="col-sm-10 col-12">
                                <input type="text" name="tanggal" id="tanggal" class="form-control" value="<?=reverse_date($result->tanggal)?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="publish" class="col-sm-2 col-12 col-form-label">Publish <span class="text-danger">*</span></label>
                            <!--end::Label-->
                            <div class="col-sm-10 col-12">
                                <select name="aktif" id="aktif" class="form-select form-select-sm" data-kt-select2="true" data-placeholder="Pilih" data-allow-clear="true">
                                    <option value="Y" <?=($result->aktif == 'Y')?"selected":""?>>Publish</option>
                                    <option value="N" <?=($result->aktif == 'N')?"selected":""?>>Tidak Publish</option>
                                </select>
                            </div>
                        </div>

                    </div>
                    <div class="card-footer">

                        <div class="text-center">

                            <button type="submit" id="submit_blog" class="btn btn-sm btn-success">
                                <span class="indicator-label"><i class="bi bi-check-lg"></i> Simpan</span>
                                <span class="indicator-progress">Please wait...
                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                        </div>

                    </div>

                <?php echo form_close(); ?>
            </div>
		</div>
	
	</div>
</div>
