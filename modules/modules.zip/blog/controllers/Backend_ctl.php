<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Backend_ctl extends MY_Admin {

    protected $mydata;

    var $data_path;

    function __construct(){
        parent::__construct();

        if (!$this->oitocauth->is_loggedin()){
            redirect(site_url('auth'));
        }

        $this->load->model('blog_m');
        $this->load->model('blog_kategori_m');

        $this->data_path = $this->config->item('data_path');
    }
    
    public function index(){

        $this->data['pagetitle'] = "Blog"; 

        $id_blog_kategori = $this->input->get('id_blog_kategori');

        $mydata['parent'] = 'Blog';
        $mydata['arrchild'][] = array('link' => site_url('dashboard'), 'name' => 'Dashboard');
        $mydata['arrchild'][] = array('link' => '#', 'name' => 'Blog');

        
        $this->data['css_add'][] = '<link href="'.base_url('assets/dist/assets/plugins/custom/datatables/datatables.bundle.css').'" rel="stylesheet" type="text/css" />';
        $this->data['js_add'][] = '<script src="'.base_url('assets/dist/assets/plugins/custom/datatables/datatables.bundle.js').'"></script>';
        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/js/page/blog/blog.js').'"></script>';

        if ($id_blog_kategori == ''){
            $reskategori = $this->blog_kategori_m->get_blog_kategori('', 0, 0);
        }else{
            $reskategori = $this->blog_kategori_m->get_blog_kategori(array('id_blog_kategori' => $id_blog_kategori), 0, 0);
        }
        $mydata['reskategori'] = $reskategori;

        if (!empty($id_blog_kategori)){
            $where['blog.id_blog_kategori'] = $id_blog_kategori;
        }

        $arrParams['arrjoin']['blog_kategori']['statement'] = 'blog_kategori.id_blog_kategori = blog.id_blog_kategori';
        $arrParams['arrjoin']['blog_kategori']['type'] = 'LEFT';

        $select = "blog.*, blog_kategori.nama as namakategori";
        $where = "";    
        $result = $this->blog_m->get_where_params($where, $select, $arrParams);
        $mydata['result'] = $result;

        $this->data['content']=$this->load->view('index',$mydata,true);

        $this->display();
    }

    public function add(){

        $this->data['pagetitle'] = "Tambah Blog"; 

        $mydata['parent'] = 'Tambah Blog';
        $mydata['arrchild'][] = array('link' => site_url('dashboard'), 'name' => 'Dashboard');
        $mydata['arrchild'][] = array('link' => site_url('blog'), 'name' => 'Blog');
        $mydata['arrchild'][] = array('link' => '#', 'name' => 'Tambah Blog');

        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/plugins/ckeditor5/ckeditor.js').'"></script>';
        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/js/page/blog/add_blog.js').'"></script>';

        $reskategori = $this->blog_kategori_m->get_blog_kategori('', 0, 0);
        $mydata['reskategori'] = $reskategori;

        $this->data['content']=$this->load->view('add',$mydata,true);
        $this->display();

    }

    public function save_add(){
        header("Content-type: text/json");

        $arrVar = array('id_blog_kategori', 'judul', 'detail', 'tanggal', 'aktif');

        foreach($arrVar as $var){
            $$var = $this->input->post($var);
        }

        $this->form_validation->set_rules('id_blog_kategori', 'Kategori', 'required', array('required' => 'Kategori harus ditambahkan'));
        $this->form_validation->set_rules('judul', 'Judul', 'required', array('required' => 'Judul Harus diisi'));
        $this->form_validation->set_rules('detail', 'Isi', 'required', array('required' => 'Isi Harus diisi'));
        $this->form_validation->set_rules('tanggal', 'Tanggal Publikasi', 'required', array('required' => 'Tanggal Publiskasi harus diisi'));

        if ($this->form_validation->run() === FALSE){
            $response['status'] = 'NOK';
            $response['message'] = validation_errors();
            echo json_encode($response);
            exit;
        }

        if (!empty($_FILES['gambar']['tmp_name'])){
            $config['upload_path'] = $this->data_path.'blog';
            $config['allowed_types'] = '*';
            $config['file_name'] = uniqid();
            $config['file_ext_tolower'] = true;
        
            $this->load->library('upload', $config);

            $data=[];

            if (! $this->upload->do_upload('gambar')){
                $error = array('error' => $this->upload->display_errors());
                $response['status'] = 'NOK';
                $response['message'] = 'Gagal mengupload file: '.$error['error'];//.$error['error'].' '.$_FILES['gambar']['type'];
                echo json_encode($response);
                exit;
            }else{

                $data = array('upload_data' => $this->upload->data());

            }

            $foto = $data['upload_data']['file_name'];
            $arrInsert['gambar'] = $foto;
        }else{
            $response['status'] = "NOK";
            $response['message'] = 'File Gambar masih kosong';
            echo json_encode($response);
            exit;
        }

        $arrInsert['judul'] = $judul;
        $arrInsert['id_blog_kategori'] = $id_blog_kategori;
        $arrInsert['detail'] = $detail;
        $arrInsert['tanggal'] = reverse_date($tanggal);
        $arrInsert['aktif'] = $aktif;
        $arrInsert['create_by'] = $this->session->userdata('ruvy_id_user');
        $arrInsert['create_date'] = date("Y-m-d H:i:s");

        if ($this->blog_m->insert_blog($arrInsert)){
            $response['status'] = 'OK';
            $response['message'] = 'Berhasil menambahkan blog';
        }else{
            $response['status'] = 'NOK';
            $response['message'] = 'Gagal menambahkan blog';
        }
        
        echo json_encode($response);

        exit;
    }

    public function edit(){

        $id_blog = $this->uri->segment(3);

        $this->data['pagetitle'] = "Update Blog"; 

        $mydata['parent'] = 'Update Blog';
        $mydata['arrchild'][] = array('link' => site_url('dashboard'), 'name' => 'Dashboard');
        $mydata['arrchild'][] = array('link' => site_url('blog'), 'name' => 'Blog');
        $mydata['arrchild'][] = array('link' => '#', 'name' => 'Update Blog');

        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/plugins/ckeditor5/ckeditor.js').'"></script>';
        $this->data['js_add'][] = '<script type="text/javascript" src="'.base_url('assets/js/page/blog/edit_blog.js').'"></script>';

        $reskategori = $this->blog_kategori_m->get_blog_kategori('', 0, 0);
        $mydata['reskategori'] = $reskategori;

        $result = $this->blog_m->get_single_blog(array('id_blog' => $id_blog));
        $mydata['result'] = $result;

        $this->data['content']=$this->load->view('edit',$mydata,true);
        $this->display();
    }

    public function save_edit(){
        header("Content-type: text/json");

        $arrVar = array('id_blog', 'id_blog_kategori', 'judul', 'detail', 'tanggal', 'aktif');

        foreach($arrVar as $var){
            $$var = $this->input->post($var);
        }

        $this->form_validation->set_rules('id_blog_kategori', 'Kategori', 'required', array('required' => 'Kategori harus ditambahkan'));
        $this->form_validation->set_rules('judul', 'Judul', 'required', array('required' => 'Judul Harus diisi'));
        $this->form_validation->set_rules('detail', 'Isi', 'required', array('required' => 'Isi Harus diisi'));
        $this->form_validation->set_rules('tanggal', 'Tanggal Publikasi', 'required', array('required' => 'Tanggal Publiskasi harus diisi'));

        if ($this->form_validation->run() === FALSE){
            $response['status'] = 'NOK';
            $response['message'] = validation_errors();
            echo json_encode($response);
            exit;
        }

        $blog = $this->blog_m->get_single_blog(array('id_blog' => $id_blog));

        if (!empty($_FILES['gambar']['tmp_name'])){
            $config['upload_path'] = $this->data_path.'blog';
            $config['allowed_types'] = '*';
            $config['file_name'] = uniqid();
            $config['file_ext_tolower'] = true;
        
            $this->load->library('upload', $config);

            $data=[];

            if (! $this->upload->do_upload('gambar')){
                $error = array('error' => $this->upload->display_errors());
                $response['status'] = 'NOK';
                $response['message'] = 'Gagal mengupload file: '.$error['error'];//.$error['error'].' '.$_FILES['gambar']['type'];
                echo json_encode($response);
                exit;
            }else{

                $data = array('upload_data' => $this->upload->data());

            }
            //delete data yang sudah ada 

            $fotogambar = $blog->gambar;

            if ($fotogambar != "" && file_exists($this->data_path.'blog/'.$fotogambar)){
                unlink($this->data_path.'blog/'.$fotogambar);
            }

            $foto = $data['upload_data']['file_name'];
            $arrUpdate['gambar'] = $foto;
        }

        $arrUpdate['judul'] = $judul;
        $arrUpdate['id_blog_kategori'] = $id_blog_kategori;
        $arrUpdate['detail'] = $detail;
        $arrUpdate['tanggal'] = reverse_date($tanggal);
        $arrUpdate['aktif'] = $aktif;
        $arrUpdate['update_by'] = $this->session->userdata('ruvy_id_user');

        if ($this->blog_m->update_blog($arrUpdate, $id_blog)){
            $response['status'] = 'OK';
            $response['message'] = 'Berhasil mengubah blog';
        }else{
            $response['status'] = 'NOK';
            $response['message'] = 'Gagal mengubah blog';
        }
        
        echo json_encode($response);

        exit;
    }

    public function delete(){
        header("Content-type: text/json");

        $id_blog = $this->input->post('id_blog');

        $res = $this->blog_m->get_single_blog(array('id_blog' => $id_blog));
        $foto = $res->gambar;
        if (!$res){
            $response['status'] = 'NOK';
            $response['message'] = 'Data tidak ditemukan';
            echo json_encode($response);
            exit;
        }

        $resdelete = $this->blog_m->delete_blog($id_blog);
        if ($resdelete){

            if ($foto != "" && file_exists($this->data_path.'blog/'.$foto)){
                unlink($this->data_path.'blog/'.$foto);
            }

            $response['status'] = 'OK';
            $response['message'] = 'Berhasil menghapus Blog';
        }else{
            $response['status'] = 'NOK';
            $response['message'] = 'Gagal menghapus Blog';
        }
        
        echo json_encode($response);

        exit;
    }

    public function delete_all(){
        header("Content-type: text/json");

        if (count($_POST['items'])>0){
            foreach($_POST['items'] as $val){

                $res = $this->blog_m->get_single_blog(array('id_blog' => $val));
                $foto = $res->foto;
                if ($foto != "" && file_exists($this->data_path.'blog/'.$foto)){
                    unlink($this->data_path.'blog/'.$foto);
                }

                $this->blog_m->delete_blog($val);
            }
        }

        $response['status'] = 'OK';
        $response['message'] = 'Berhasil menghapus Blog';

        echo json_encode($response);
        exit;
    }

}